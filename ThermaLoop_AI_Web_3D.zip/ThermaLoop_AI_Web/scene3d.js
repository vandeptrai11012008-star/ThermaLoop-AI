/*
 * THERMALOOP AI — interactive 3D digital twin (dependency-free software renderer on Canvas 2D).
 * Visualises the same simulator state shown elsewhere: 64 GPUs in 8 racks, heat exchanger, heat pump,
 * thermal store, four heat destinations and heat rejection. Illustrative geometry, not a CAD model.
 * Drag = orbit · wheel = zoom · hover a GPU tile = its temperature.
 */
(() => {
  'use strict';
  const wrap = document.getElementById('scene3d');
  if (!wrap) return;
  const canvas = wrap.querySelector('canvas');
  const ctx = canvas.getContext('2d');
  const tip = wrap.querySelector('.scene3d-tip');
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const lerp = (a, b, t) => a + (b - a) * t;

  // ---------- live data (written by simulator.js through ThermaLoop3D.update) ----------
  const D = {
    cells: Array(64).fill(45), captured: 0, heat: 0, heatDemand: 1, itKW: 0, util: 0,
    branch: { building: 0, laboratory: 0, seed: 0, greenhouse: 0 }, demand: { building: 1, laboratory: 1, seed: 1, greenhouse: 1 },
    storage: 0, storageCap: 100, storageRate: 0, rejected: 0, coolantFlow: 4, diagnosis: 'normal', cop: 3.4, backup: 0, peak: 45
  };
  const disp = { cells: Array(64).fill(45), heat: 0, captured: 0, rejected: 0, storage: 0, flowRet: 1, br: [0, 0, 0, 0], brFlow: [0, 0, 0, 0] };
  let lastStorage = null;

  // ---------- math ----------
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const norm = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const LIGHT = norm([-0.35, 0.85, 0.55]);

  // ---------- camera ----------
  const VIEWS = {
    overview: { yaw: 0.72, pitch: 0.58, dist: 52, target: [-1, 1.5, 0] },
    hall: { yaw: 0.18, pitch: 0.3, dist: 24, target: [-11, 2.4, 0] },
    loads: { yaw: 0.9, pitch: 0.6, dist: 34, target: [10, 1.5, 0] }
  };
  const cam = { ...VIEWS.overview, target: [...VIEWS.overview.target] };
  let tween = null, autoRotate = true, W = 800, H = 480, fl = 600, camPos, R, U, F;

  function setupCamera() {
    const cp = Math.cos(cam.pitch);
    camPos = [cam.target[0] + cam.dist * Math.sin(cam.yaw) * cp, cam.target[1] + cam.dist * Math.sin(cam.pitch), cam.target[2] + cam.dist * Math.cos(cam.yaw) * cp];
    F = norm(sub(cam.target, camPos));
    R = norm(cross(F, [0, 1, 0]));
    U = cross(R, F);
    fl = (H / 2) / Math.tan(0.33);
  }
  function proj(p) {
    const d = sub(p, camPos), z = dot(d, F);
    if (z < 0.6) return null;
    return [W / 2 + fl * dot(d, R) / z, H / 2 - fl * dot(d, U) / z, z];
  }
  function goTo(name) {
    const v = VIEWS[name]; if (!v) return;
    tween = { t: 0, from: { yaw: cam.yaw, pitch: cam.pitch, dist: cam.dist, target: [...cam.target] }, to: v };
    autoRotate = false; syncButtons(name);
  }

  // ---------- colour helpers ----------
  const STOPS = [[38, [23, 100, 149]], [51, [40, 162, 180]], [65, [220, 166, 85]], [78, [241, 113, 79]], [95, [194, 48, 88]]];
  function tempRGB(t) {
    if (t <= 38) return STOPS[0][1].slice();
    for (let i = 1; i < STOPS.length; i++) if (t <= STOPS[i][0]) {
      const a = STOPS[i - 1], b = STOPS[i], p = (t - a[0]) / (b[0] - a[0]);
      return a[1].map((v, j) => v + (b[1][j] - v) * p);
    }
    return STOPS[4][1].slice();
  }
  const css = (c, k = 1, a = 1) => `rgba(${Math.round(clamp(c[0] * k, 0, 255))},${Math.round(clamp(c[1] * k, 0, 255))},${Math.round(clamp(c[2] * k, 0, 255))},${a})`;

  // ---------- mesh helpers ----------
  function boxMesh(cx, cy, cz, w, h, d) {
    const x0 = cx - w / 2, x1 = cx + w / 2, y0 = cy - h / 2, y1 = cy + h / 2, z0 = cz - d / 2, z1 = cz + d / 2;
    const v = [[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]];
    return { v, f: [[4, 5, 6, 7], [1, 0, 3, 2], [5, 1, 2, 6], [0, 4, 7, 3], [3, 7, 6, 2], [0, 1, 5, 4]], c: [cx, cy, cz] };
  }
  function cylMesh(cx, y0, cz, r, h, n = 18) {
    const v = [], f = [];
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; v.push([cx + r * Math.cos(a), y0, cz + r * Math.sin(a)]); }
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; v.push([cx + r * Math.cos(a), y0 + h, cz + r * Math.sin(a)]); }
    for (let i = 0; i < n; i++) f.push([i, (i + 1) % n, n + (i + 1) % n, n + i]);
    f.push(Array.from({ length: n }, (_, i) => n + i));
    return { v, f, c: [cx, y0 + h / 2, cz] };
  }
  function prismMesh(cx, cy, cz, w, h, d, roof) { // box with a gabled roof along z (greenhouse)
    const x0 = cx - w / 2, x1 = cx + w / 2, y0 = cy - h / 2, y1 = cy + h / 2, z0 = cz - d / 2, z1 = cz + d / 2;
    const v = [[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], [cx, y1 + roof, z0], [cx, y1 + roof, z1]];
    return { v, f: [[4, 5, 6, 7], [1, 0, 3, 2], [5, 1, 2, 6], [0, 4, 7, 3], [7, 6, 9], [3, 2, 8], [3, 7, 9, 8], [2, 8, 9, 6], [0, 1, 5, 4]], c: [cx, cy + roof / 3, cz] };
  }

  // ---------- scene description ----------
  const GRID_Z = [-3.2, 2.8];
  const rackX = c => -15.6 + c * 3.0;
  const BUILD_Z = [-10.5, -3.5, 3.5, 10.5];
  const BKEYS = ['building', 'laboratory', 'seed', 'greenhouse'];
  const BNAMES = ['Building heating', 'Robotics / materials labs', 'Seed germination tests', 'Greenhouse'];
  const COL = {
    rack: [22, 36, 56], slab: [24, 42, 62], hx: [150, 100, 58], hp: [52, 124, 122], tank: [140, 150, 200],
    bld: [58, 84, 112], lab: [70, 92, 122], seed: [74, 108, 100], green: [70, 130, 108], tower: [90, 104, 124]
  };
  const gpuTiles = []; // {mesh, i}
  for (let i = 0; i < 64; i++) {
    const r = Math.floor(i / 8), lane = i % 8, col = r % 4, row = Math.floor(r / 4);
    const cx = rackX(col), cz = GRID_Z[row] + 1.0 + 0.07;
    gpuTiles.push({ i, mesh: boxMesh(cx, 0.55 + lane * 0.53, cz, 1.3, 0.4, 0.14), rack: r });
  }
  const racks = [];
  for (let r = 0; r < 8; r++) racks.push({ r, mesh: boxMesh(rackX(r % 4), 2.4, GRID_Z[Math.floor(r / 4)], 1.7, 4.8, 2.0) });
  const staticMeshes = [
    { mesh: boxMesh(-11.25, -0.12, 0, 12.6, 0.24, 15), color: COL.slab, k: 0.8 },
    { mesh: boxMesh(-1, 1.5, 0, 3, 3, 3), color: COL.hx, k: 1 },
    { mesh: boxMesh(4.4, 1.5, 0, 4.2, 3, 4), color: COL.hp, k: 1 },
    { mesh: boxMesh(-1, 1.2, 9, 3.4, 2.4, 3), color: COL.tower, k: 1 }
  ];
  const buildMeshes = [
    { mesh: boxMesh(13.5, 2.4, BUILD_Z[0], 4.2, 4.8, 3.6), color: COL.bld },
    { mesh: boxMesh(13.5, 1.5, BUILD_Z[1], 4.2, 3.0, 3.6), color: COL.lab },
    { mesh: boxMesh(13.5, 1.0, BUILD_Z[2], 4.2, 2.0, 3.6), color: COL.seed },
    { mesh: prismMesh(13.5, 1.3, BUILD_Z[3], 4.2, 2.6, 3.6, 1.4), color: COL.green }
  ];
  // Pipes: hot supply, cool return. 'flow' is evaluated each frame in [0,1].
  const P = (pts, kind, flowFn, dirFn) => ({ pts, kind, flowFn, dirFn: dirFn || (() => 1), len: 0, cum: [0] });
  const pipes = [
    P([[-5, 2.2, -0.2], [-2.5, 2.2, -0.2]], 'hot', () => disp.captured / 80),
    P([[0.5, 2.2, 0], [2.3, 2.2, 0]], 'hot', () => disp.captured / 80),
    P([[6.5, 2.2, 0], [8, 2.2, 0]], 'hot', () => disp.heat / 85),
    P([[8, 2.2, -10.5], [8, 2.2, 10.5]], 'hot', () => disp.heat / 85),
    P([[8, 2.2, -8], [5.2, 2.2, -8]], 'store', () => Math.abs(disp.storageRate) / 30, () => Math.sign(D.storageRate) || 1),
    ...BUILD_Z.map((z, k) => P([[8, 2.2, z], [11.2, 2.2, z]], 'hot', () => disp.brFlow[k])),
    ...BUILD_Z.map((z, k) => P([[11.2, 0.6, z + 0.9], [9.4, 0.6, z + 0.9]], 'cool', () => disp.brFlow[k])),
    P([[9.4, 0.6, -13], [9.4, 0.6, 11.4]], 'cool', () => disp.heat / 85 * 0.9 + 0.05, () => -1),
    P([[9.4, 0.6, -13], [-11, 0.6, -13], [-11, 0.6, -7]], 'cool', () => disp.flowRet),
    P([[-1, 0.7, 1.5], [-1, 0.7, 7.5]], 'rej', () => disp.rejected / 70)
  ];
  pipes.forEach(p => { for (let i = 1; i < p.pts.length; i++) { p.len += Math.hypot(...sub(p.pts[i], p.pts[i - 1])); p.cum.push(p.len); } });
  const along = (p, s) => {
    for (let i = 1; i < p.pts.length; i++) if (s <= p.cum[i] || i === p.pts.length - 1) {
      const t = (s - p.cum[i - 1]) / (p.cum[i] - p.cum[i - 1] || 1), a = p.pts[i - 1], b = p.pts[i];
      return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
    }
    return p.pts[0];
  };
  const PIPE_COL = { hot: [255, 170, 95], cool: [98, 200, 240], store: [170, 155, 245], rej: [255, 120, 110] };

  // ---------- frame assembly ----------
  let items = [], pickList = [], hover = -1, time = 0;
  function pushMesh(m, color, k, alpha, opts = {}) {
    for (const f of m.f) {
      if (f.length < 3) continue;
      const vs = f.map(i => m.v[i]);
      let n = norm(cross(sub(vs[1], vs[0]), sub(vs[2], vs[0])));
      const fc = [0, 0, 0]; vs.forEach(v => { fc[0] += v[0] / vs.length; fc[1] += v[1] / vs.length; fc[2] += v[2] / vs.length; });
      if (dot(n, sub(fc, m.c)) < 0) n = [-n[0], -n[1], -n[2]];
      if (dot(n, sub(camPos, fc)) <= 0) continue; // back-face
      const pts = []; let zs = 0, ok = true;
      for (const v of vs) { const q = proj(v); if (!q) { ok = false; break; } pts.push(q); zs += q[2]; }
      if (!ok) continue;
      const shade = (0.42 + 0.58 * Math.max(0, dot(n, LIGHT))) * k;
      items.push({ t: 'poly', pts, z: zs / pts.length - (opts.gpu !== undefined ? 1.2 : 0), fill: css(color, shade, alpha), stroke: opts.stroke || 'rgba(190,225,255,0.10)', gpu: opts.gpu, lw: opts.lw || 1 });
    }
  }
  function pushLine(a, b, width, style, bias = 0) {
    const pa = proj(a), pb = proj(b); if (!pa || !pb) return;
    items.push({ t: 'line', pa, pb, z: (pa[2] + pb[2]) / 2 + bias, w: width, style });
  }
  function pushDot(p, r, style, bias = -0.3) {
    const q = proj(p); if (!q) return;
    items.push({ t: 'dot', q, z: q[2] + bias, r: r * fl / q[2], style });
  }
  const labels = [];
  const label = (p, text, sub, tone) => labels.push({ p, text, sub, tone });

  function build(dt) {
    items = []; pickList = []; labels.length = 0;
    // smoothing
    const k = 1 - Math.pow(0.0008, dt);
    for (let i = 0; i < 64; i++) disp.cells[i] = lerp(disp.cells[i], D.cells[i], k);
    disp.heat = lerp(disp.heat, D.heat, k); disp.captured = lerp(disp.captured, D.captured, k);
    disp.rejected = lerp(disp.rejected, D.rejected, k); disp.storage = lerp(disp.storage, D.storage, k);
    disp.storageRate = lerp(disp.storageRate, D.storageRate, k);
    disp.flowRet = lerp(disp.flowRet, clamp(D.coolantFlow / 4, 0.15, 1.1) * clamp(D.itKW / 70, 0.25, 1), k);
    BKEYS.forEach((key, i) => {
      const dem = Math.max(0.01, D.demand[key]);
      disp.br[i] = lerp(disp.br[i], clamp(D.branch[key] / dem, 0, 1), k);
      disp.brFlow[i] = lerp(disp.brFlow[i], clamp(D.branch[key] / 40, 0, 1), k);
    });

    // static geometry
    staticMeshes.forEach((s, i) => {
      let col = s.color, kk = s.k;
      if (i === 1) kk = 0.8 + 0.5 * clamp(disp.captured / 80, 0, 1);
      if (i === 2) kk = 0.8 + 0.5 * clamp(disp.heat / 85, 0, 1);
      pushMesh(s.mesh, col, kk, 1);
    });
    // racks and GPU tiles
    const fault = D.diagnosis === 'flow-restriction' || D.diagnosis === 'unknown-anomaly';
    racks.forEach(r => pushMesh(r.mesh, COL.rack, 1, 1, { stroke: 'rgba(120,170,220,0.22)' }));
    gpuTiles.forEach(g => {
      const t = disp.cells[g.i];
      pushMesh(g.mesh, tempRGB(t), 1.1, 1, { gpu: g.i, stroke: hover === g.i ? 'rgba(255,255,255,0.95)' : 'rgba(10,20,36,0.5)', lw: hover === g.i ? 2 : 1 });
    });
    // destinations (glow with delivered / demand)
    buildMeshes.forEach((b, i) => {
      const f = disp.br[i];
      const warm = [lerp(COL.bld[0], 255, f * 0.7), lerp(COL.bld[1], 150, f * 0.55), lerp(COL.bld[2], 70, f * 0.2)];
      const base = [b.color[0] * (1 - f * 0.3) + warm[0] * f * 0.9, b.color[1] * (1 - f * 0.3) + warm[1] * f * 0.9, b.color[2] * (1 - f * 0.3) + warm[2] * f * 0.9];
      pushMesh(b.mesh, base, 0.9 + 0.3 * f, 1);
    });
    // thermal storage tank with level
    const cap = Math.max(1, D.storageCap), level = clamp(disp.storage / cap, 0, 1);
    const tx = 4.4, tz = -8, tr = 1.9, th = 5;
    pushMesh(cylMesh(tx, 0, tz, tr, th, 20), COL.tank, 1, 0.38, { stroke: 'rgba(200,210,255,0.35)' });
    if (level > 0.01) pushMesh(cylMesh(tx, 0.02, tz, tr * 0.88, Math.max(0.05, th * level), 20), [255, 150 + 60 * level, 80], 1.1, 0.85, { stroke: 'rgba(255,200,140,0.2)' });
    // fans
    const spin = time * (1.5 + 5 * clamp(disp.heat / 85, 0, 1));
    const fan = (cx, cy, cz, r, sp) => { for (let b = 0; b < 3; b++) { const a = sp + b * 2.094; pushLine([cx, cy, cz], [cx + r * Math.cos(a), cy, cz + r * Math.sin(a)], 0.22, 'rgba(210,230,245,0.9)', -0.5); } };
    pushMesh(cylMesh(4.4, 3.0, 0, 1.5, 0.12, 18), [30, 50, 70], 1, 1);
    fan(4.4, 3.2, 0, 1.3, spin);
    pushMesh(cylMesh(-1, 2.4, 9, 1.3, 0.12, 18), [30, 50, 70], 1, 1);
    fan(-1, 2.6, 9, 1.15, time * (1 + 5 * clamp(disp.rejected / 70, 0, 1)));
    // data hall outline
    const hx0 = -17.55, hx1 = -4.95, hz0 = -7.5, hz1 = 7.5, hh = 6;
    const C = [[hx0, 0, hz0], [hx1, 0, hz0], [hx1, 0, hz1], [hx0, 0, hz1]];
    for (let i = 0; i < 4; i++) {
      const a = C[i], b = C[(i + 1) % 4];
      pushLine([a[0], hh, a[2]], [b[0], hh, b[2]], 0.07, 'rgba(120,190,240,0.35)', 3);
      pushLine(a, [a[0], hh, a[2]], 0.07, 'rgba(120,190,240,0.25)', 3);
    }
    // pipes + particles
    pipes.forEach(p => {
      const flow = clamp(p.flowFn(), 0, 1), col = PIPE_COL[p.kind], dir = p.dirFn();
      for (let i = 1; i < p.pts.length; i++) pushLine(p.pts[i - 1], p.pts[i], 0.2, css(col, 0.55, 0.35 + 0.35 * Math.min(1, flow * 1.5)), 1);
      if (flow < 0.02) return;
      const n = Math.max(2, Math.round(p.len / 1.6));
      for (let j = 0; j < n; j++) {
        let ph = ((j / n) + time * (0.04 + 0.16 * flow) * dir / Math.max(1, p.len / 8)) % 1; if (ph < 0) ph += 1;
        pushDot(along(p, ph * p.len), 0.15 + 0.07 * flow, css(col, 1.1, 0.9));
      }
    });
    // pulsing marker over affected racks
    if (fault) {
      const pulse = 0.5 + 0.5 * Math.sin(time * 5);
      [5, 6].forEach(r => { const m = racks[r].mesh; const top = [m.c[0], 5.2, m.c[2] + 0.8]; pushDot(top, 0.28 + 0.1 * pulse, `rgba(251,113,133,${0.55 + 0.4 * pulse})`, -1); });
    }
    // labels
    label([-11.2, 6.6, 0], 'AI DATA HALL', `64 GPUs · ${D.itKW.toFixed(1)} kW IT · ${(D.util * 100).toFixed(0)}% util`, 'cool');
    label([-1, 3.9, 0], 'HEAT EXCHANGER', `${disp.captured.toFixed(1)} kW capturable`, 'warm');
    label([4.4, 4.4, 0], `HEAT PUMP · COP ${D.cop.toFixed(1)}`, `${disp.heat.toFixed(1)} kW delivered`, 'warm');
    label([4.4, 6, -8], 'THERMAL STORE', `${disp.storage.toFixed(1)} / ${D.storageCap} kWh`, 'store');
    label([-1, 3.5, 9], 'HEAT REJECTION', `${disp.rejected.toFixed(1)} kW to ambient`, 'rej');
    buildMeshes.forEach((b, i) => label([13.5, [5.2, 3.4, 2.4, 4.2][i] + 0.2, BUILD_Z[i]], BNAMES[i].toUpperCase(), `${D.branch[BKEYS[i]].toFixed(1)} of ${D.demand[BKEYS[i]].toFixed(1)} kW`, 'warm'));
    if (D.backup > 0.5) label([8, 3.4, 11], 'ELECTRIC BACKUP', `${D.backup.toFixed(1)} kW resistance`, 'rej');
  }

  // ---------- drawing ----------
  function pill(x, y, title, subText, tone) {
    ctx.font = '700 10px Inter, system-ui, sans-serif';
    const w1 = ctx.measureText(title).width; ctx.font = '500 10px Inter, system-ui, sans-serif';
    const w2 = ctx.measureText(subText).width, w = Math.max(w1, w2) + 16, h = 33;
    const accent = { cool: '#62c9f2', warm: '#ffb276', store: '#aa9bf5', rej: '#fb8b93' }[tone] || '#62c9f2';
    x = clamp(x - w / 2, 4, W - w - 4); y = clamp(y - h, 4, H - h - 4);
    ctx.fillStyle = 'rgba(8,19,33,0.88)'; ctx.strokeStyle = accent; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, 7) : ctx.rect(x, y, w, h); ctx.fill(); ctx.globalAlpha = 0.55; ctx.stroke(); ctx.globalAlpha = 1;
    ctx.fillStyle = '#e7f3ff'; ctx.font = '700 10px Inter, system-ui, sans-serif'; ctx.textBaseline = 'alphabetic';
    ctx.fillText(title, x + 8, y + 14);
    ctx.fillStyle = accent; ctx.font = '500 10px Inter, system-ui, sans-serif'; ctx.fillText(subText, x + 8, y + 27);
  }
  function draw() {
    ctx.clearRect(0, 0, W, H);
    const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#0a1728'); g.addColorStop(1, '#0d2036');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // ground grid
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(98,201,242,0.10)';
    for (let x = -24; x <= 24; x += 4) { const a = proj([x, 0, -16]), b = proj([x, 0, 16]); if (a && b) { ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } }
    for (let z = -16; z <= 16; z += 4) { const a = proj([-24, 0, z]), b = proj([24, 0, z]); if (a && b) { ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } }
    items.sort((a, b) => b.z - a.z);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    for (const it of items) {
      if (it.t === 'poly') {
        ctx.beginPath(); ctx.moveTo(it.pts[0][0], it.pts[0][1]);
        for (let i = 1; i < it.pts.length; i++) ctx.lineTo(it.pts[i][0], it.pts[i][1]);
        ctx.closePath(); ctx.fillStyle = it.fill; ctx.fill(); ctx.strokeStyle = it.stroke; ctx.lineWidth = it.lw; ctx.stroke();
        if (it.gpu !== undefined) pickList.push(it);
      } else if (it.t === 'line') {
        ctx.beginPath(); ctx.moveTo(it.pa[0], it.pa[1]); ctx.lineTo(it.pb[0], it.pb[1]);
        ctx.strokeStyle = it.style; ctx.lineWidth = Math.max(1, it.w * fl / ((it.pa[2] + it.pb[2]) / 2)); ctx.stroke();
      } else {
        ctx.beginPath(); ctx.arc(it.q[0], it.q[1], Math.max(1, it.r), 0, 6.2832); ctx.fillStyle = it.style; ctx.fill();
      }
    }
    const reach = cam.dist * 0.7 + 4;
    for (const l of labels) { if (Math.hypot(...sub(l.p, cam.target)) > reach) continue; const q = proj(l.p); if (q) pill(q[0], q[1], l.text, l.sub, l.tone); }
    // rack ids on the floor of the hall
    ctx.font = '600 9px Inter, system-ui, sans-serif'; ctx.fillStyle = 'rgba(160,190,215,0.8)'; ctx.textAlign = 'center';
    for (let r = 0; r < 8; r++) { const q = proj([rackX(r % 4), 0.02, GRID_Z[Math.floor(r / 4)] + 1.9]); if (q) ctx.fillText('R' + (r + 1), q[0], q[1] + 3); }
    ctx.textAlign = 'start';
  }

  // ---------- loop ----------
  let last = performance.now(), visible = true;
  function frame(now) {
    requestAnimationFrame(frame);
    if (!visible || W < 10) return;
    const dt = Math.min(0.1, (now - last) / 1000); last = now; time += dt;
    if (tween) {
      tween.t = Math.min(1, tween.t + dt / 0.9); const e = tween.t * tween.t * (3 - 2 * tween.t);
      cam.yaw = lerp(tween.from.yaw, tween.to.yaw, e); cam.pitch = lerp(tween.from.pitch, tween.to.pitch, e); cam.dist = lerp(tween.from.dist, tween.to.dist, e);
      cam.target = tween.from.target.map((v, i) => lerp(v, tween.to.target[i], e)); if (tween.t >= 1) tween = null;
    } else if (autoRotate && !dragging) cam.yaw = 0.72 + Math.sin(time * 0.18) * 0.3;
    setupCamera(); build(dt); draw();
  }
  function resize() {
    const r = wrap.getBoundingClientRect(); if (r.width < 10) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    W = r.width; H = r.height; canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  new ResizeObserver(resize).observe(wrap);
  new IntersectionObserver(es => { visible = es[0].isIntersecting; }, { threshold: 0 }).observe(wrap);

  // ---------- interaction ----------
  let dragging = false, px = 0, py = 0, moved = 0;
  canvas.addEventListener('pointerdown', e => { dragging = true; moved = 0; px = e.clientX; py = e.clientY; canvas.setPointerCapture(e.pointerId); autoRotate = false; tween = null; syncButtons(''); });
  canvas.addEventListener('pointermove', e => {
    const rect = canvas.getBoundingClientRect(), mx = e.clientX - rect.left, my = e.clientY - rect.top;
    if (dragging) {
      moved += Math.abs(e.clientX - px) + Math.abs(e.clientY - py);
      cam.yaw -= (e.clientX - px) * 0.007; cam.pitch = clamp(cam.pitch + (e.clientY - py) * 0.005, 0.08, 1.35); px = e.clientX; py = e.clientY; hover = -1; tip.hidden = true; return;
    }
    hover = -1;
    for (let i = pickList.length - 1; i >= 0; i--) { const p = pickList[i].pts; let inside = false; for (let a = 0, b = p.length - 1; a < p.length; b = a++) { if ((p[a][1] > my) !== (p[b][1] > my) && mx < (p[b][0] - p[a][0]) * (my - p[a][1]) / (p[b][1] - p[a][1]) + p[a][0]) inside = !inside; } if (inside) { hover = pickList[i].gpu; break; } }
    if (hover >= 0) { tip.hidden = false; tip.textContent = `GPU ${String(hover + 1).padStart(2, '0')} · rack R${Math.floor(hover / 8) + 1} · ${D.cells[hover].toFixed(1)} °C`; tip.style.left = Math.min(W - 190, mx + 14) + 'px'; tip.style.top = (my + 14) + 'px'; } else tip.hidden = true;
  });
  const end = () => { dragging = false; };
  canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);
  canvas.addEventListener('pointerleave', () => { hover = -1; tip.hidden = true; });
  canvas.addEventListener('wheel', e => { e.preventDefault(); cam.dist = clamp(cam.dist * Math.exp(e.deltaY * 0.001), 12, 80); autoRotate = false; tween = null; }, { passive: false });
  const btns = wrap.querySelectorAll('[data-view]');
  function syncButtons(name) { btns.forEach(b => b.classList.toggle('active', b.dataset.view === name || (name === 'auto' && b.dataset.view === 'auto' && autoRotate))); }
  btns.forEach(b => b.addEventListener('click', () => {
    const v = b.dataset.view;
    if (v === 'auto') { autoRotate = !autoRotate; if (autoRotate) { tween = { t: 0, from: { yaw: cam.yaw, pitch: cam.pitch, dist: cam.dist, target: [...cam.target] }, to: VIEWS.overview }; } syncButtons(autoRotate ? 'auto' : ''); } else goTo(v);
  }));

  // ---------- public hook ----------
  window.ThermaLoop3D = {
    update(v, controls) {
      D.cells = v.cells; D.captured = v.captured; D.heat = v.heat; D.heatDemand = v.heatDemand; D.itKW = v.itKW; D.util = v.util;
      D.branch = v.branchDelivered; D.storage = v.storage; D.storageCap = controls.storageCap; D.rejected = v.rejected;
      D.coolantFlow = v.coolantFlow; D.diagnosis = v.diagnosis; D.backup = v.backup; D.peak = v.peakTemp;
      D.demand = window.ThermaLoopSimulator.thermalDemand(controls.outside);
      if (lastStorage !== null) D.storageRate = (v.storage - lastStorage) * 60; // kW into (+) / out of (-) the store
      lastStorage = v.storage;
    },
    reset() { lastStorage = null; D.storageRate = 0; }
  };
  resize(); syncButtons('auto'); requestAnimationFrame(frame);
})();
