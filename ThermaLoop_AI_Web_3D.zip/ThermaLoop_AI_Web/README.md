# ThermaLoop AI — Interactive Research Digital Twin

A self-contained, dependency-free simulation website for an integrated AI data center, five joint optimization strategies, heat reuse, and chip thermal anomaly detection.

## Run locally

Open `index.html` in Chrome, Edge, Firefox, or Safari. No build step or network access is required. Alternatively start a local server inside this directory:

```bash
python -m http.server 8000
```

Navigate to `http://localhost:8000`.

## Publish free via GitHub Pages

1. Make a new public repository such as `thermaloop-ai` on GitHub.
2. Upload `index.html`, `styles.css`, `simulator.js`, and `scene3d.js` into the repository root.
3. Repository → Settings → Pages → Deploy from a branch → `main`, `/ (root)` → Save.
4. Open the GitHub Pages URL shown in Settings once publishing finishes.

## Interactive features

- **3D digital twin**: an orbitable 3D scene (drag to rotate, scroll to zoom, view presets, hover any GPU tile for its temperature) of the data hall, heat exchanger, heat pump, thermal store, four heat destinations and heat rejection. Tiles, pipes, building glow, tank level and fan speed are driven by the live simulation. It is a dependency-free Canvas renderer (`scene3d.js`); a `2D schematic` button restores the original SVG diagram.

- Data-center digital twin with 64 GPUs in 8 racks, coolant supply/return, HX, heat pump, thermal store and backup cooling.
- Four independently controlled thermal destinations: building heating, robotics/materials labs, seed germination testing (NOT cold storage), and greenhouse.
- Five configurable optimizations: model routing, GPU DVFS, prefill/decode specialization, thermal-aware scheduling, and thermal anomaly diagnostics.
- Scenario selector, live pause/step/reset, sliders for task arrivals / outdoor temperature / renewables / thermal storage, and cooling fault injection.
- Performance and temperature charts, a 64-GPU heat map, fault cause hypotheses, 60-minute seeded baseline benchmark and simulated CSV export.
- All visuals are locally generated using HTML, CSS, SVG and Canvas. No external library, CDN, API or credentials needed.

## Equations and assumptions

A one-minute simulation step processes queued tasks with synthetic complexity, token sizes and deadlines. Tasks consume GPU-seconds based on **assumed** per-token coefficients; 64 GPUs each supply up to 60 GPU-seconds per minute at reference clock (adjusted by efficiency and DVFS). Small and large models differ in coefficients, with a synthetic probabilistic quality proxy. The prefill/decode optimizer changes required modeled GPU-seconds and adds a handoff cost. The thermal scheduler may defer flexible requests for at most two simulated minutes if heat demand is low and deadline slack exists.

Illustrative GPU electric power in kW:

`P_IT = P_nonGPU + 64 * (P_GPU_idle + P_GPU_dynamic * utilization * clock^2.15)`

Illustrative heat available at the heat pump source in kW:

`Q_capture = P_IT * 0.82 * 0.92`

Heat-pump potential output with nominal `COP = 3.4`:

`Q_HP_potential = Q_capture * COP / (COP - 1)`

Heat pump power:

`P_HP = Q_HP_output / COP`

Site electric power (including resistive backup heating for unmet space-heat demand):

`P_site = P_IT + P_cooling_aux + P_HP + P_site_overhead + P_backup_heat`

The thermal tank is a one-hour-equivalent buffer in kWh with simplified charging/discharging efficiency and kW rate caps. Renewable % offsets estimated grid draw, NOT site electric consumption. Recovered heat goes through separate secondary heating circuits, never through the server coolant loop. The seed refrigeration/storage portion remains isolated from heating.

The GPU health model uses an assumed temperature trajectory, per-device spatial variation, coolant flow reduction, and a residual between predicted and observed bulk chip temperature. It generates **hypotheses**, not real hardware diagnoses. GPU heat map cells are distinct devices, not an actual die-level infrared scan.

## Limitations and requirements for genuine research use

- **Not calibrated:** numbers are illustrative and not validated measurements, real benchmarks, or estimates of a specific commercial GPU.
- **Not a direct controller:** no connection to real GPUs, pumps, sensors, heat pumps or critical safety equipment.
- **No proven novelty claim:** waste-heat recovery, LLM routing, GPU DVFS and prefill/decode disaggregation all have existing literature; the *integrated, experimentally validated joint optimization under campus heat demands* is the research question.
- **Latency:** deadline success is simulated scheduling feasibility, not observed LLM response latency. The token quality percentage is a synthetic proxy and requires real benchmark evaluation.
- **Thermodynamics:** the model simplifies transient heat transfer, COP changes with temperatures, capture fractions, exchanger approach temperature, mixing control, storage losses, pump control, building occupancy, cold-storage refrigeration and network transport.
- **Validation plan:** use hardware telemetry (e.g. Nvidia DCGM), request traces, PDU measurements, temperature and flow sensors, heat-pump datasheets, coupled hydronic equations and actual HVAC demand profiles. Add physical constraints, statistical uncertainty and a protective independent automation layer before any real operation.

## File list

- `index.html`: responsive web interface and vector systems schematic.
- `styles.css`: dark professional dashboard design.
- `simulator.js`: reproducible calculation engine and UI interactions.
