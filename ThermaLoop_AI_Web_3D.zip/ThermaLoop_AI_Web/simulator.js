/*
 * THERMALOOP AI — educational / research concept digital twin (no hardware control).
 * All parameters are declared below and are illustrative, NOT calibrated to actual GPU servers.
 * Calculations are computed, not pre-rendered or randomized KPI numbers.
 */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const fmt = (v, digits = 1) => Number.isFinite(v) ? v.toFixed(digits) : '--';
  const CONFIG = Object.freeze({
    gpuCount: 64, rackCount: 8, gpuIdleKW: 0.14, gpuDynamicKW: 0.64,
    nonGpuITKW: 19, schedulerEfficiency: 0.92, gpuCapacitySecondsPerMinute: 60,
    captureFraction: 0.82, heatExchangerEffectiveness: 0.92, heatPumpCOP: 3.4,
    normalCoolantFlowKgS: 4.0, simSecondsPerMinute: 60,
    seed: 521143, maxQueue: 7000, historyLength: 90
  });
  function rngFromSeed(seed) {
    let a = seed >>> 0;
    return () => {
      a += 0x6D2B79F5;
      let t = a;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const toggles = ['routing', 'dvfs', 'disagg', 'thermal', 'diagnostics'];
  const allOn = () => ({ routing:true, dvfs:true, disagg:true, thermal:true, diagnostics:true });
  const allOff = () => ({ routing:false, dvfs:false, disagg:false, thermal:false, diagnostics:false });
  function readControls() {
    const active = {};
    for (const key of toggles) active[key] = $(key + 'Toggle').checked;
    return {
      active, arrivals: Number($('demandRange').value),
      outside: Number($('tempRange').value),
      renewables: Number($('solarRange').value) / 100,
      storageCap: Number($('storageRange').value)
    };
  }
  function createState(controls, seed = CONFIG.seed) {
    return {
      t: 0, controls: JSON.parse(JSON.stringify(controls)), random: rngFromSeed(seed),
      queue: [], jobsMade: 0, fault: null, faultTime: -1,
      temp: 45, current: null, storageKWh: controls.storageCap * 0.25,
      total: { energyKWh:0, tokens:0, completions:0, deadlines:0, quality:0, heatKWh:0, generated:0 },
      history: [], lastDiagnosis:'normal', lastAlert:false
    };
  }
  function thermalDemand(outside) {
    // kW: illustrative branches; seed cold storage is NOT heated.
    return {
      building: 12 + clamp((20 - outside) * 0.70, 0, 31),
      laboratory: 7.0,
      seed: 3.0,
      greenhouse: 5 + clamp((18 - outside) * 1.23, 0, 34)
    };
  }
  function createJob(state, flags) {
    const r = state.random;
    const complexity = r();
    const small = !!flags.routing && complexity <= 0.56;
    const inputTokens = Math.round(400 + r() * 2200);
    const outputTokens = Math.round(95 + r() * 400);
    const flexibility = r() < 0.38;
    const deadline = state.t + (flexibility ? 4 : 2) + Math.floor(r() * 3);
    // Effective per-job workload: GPU-seconds, independent of cluster parallelism.
    const prefill = inputTokens * (small ? 0.0015 : 0.0048) / (flags.disagg ? 1.13 : 1);
    const decode = outputTokens * (small ? 0.012 : 0.044) / (flags.disagg ? 1.10 : 1);
    const communication = flags.disagg ? 0.34 : 0;
    const work = prefill + decode + communication;
    const qualityProbability = small ? clamp(0.978 - 0.08 * complexity, 0, 1) : clamp(0.995 - 0.019 * complexity, 0, 1);
    const good = r() < qualityProbability;
    return { id:++state.jobsMade, created:state.t, deadline, flexible:flexibility,
      small, inputTokens, outputTokens, remaining:work, good };
  }
  function step(state, override) {
    const c = override || state.controls;
    state.controls = JSON.parse(JSON.stringify(c));
    const f = c.active, time = state.t;
    const demand = thermalDemand(c.outside);
    const heatDemand = Object.values(demand).reduce((a, b) => a + b, 0);
    // Sinusoidal daily-like demand modulation and seeded noise.
    const arrivals = clamp(Math.round(c.arrivals * (1 + 0.14 * Math.sin(time / 11) + 0.05 * Math.cos(time / 4)) + (state.random() - 0.5) * 12), 0, 500);
    for(let j = 0; j < arrivals && state.queue.length < CONFIG.maxQueue; j++) state.queue.push(createJob(state, f));
    state.total.generated += arrivals;
    const queueWork = state.queue.reduce((sum, j) => sum + j.remaining, 0);
    let clock = f.dvfs ? clamp(0.72 + 0.28 * queueWork / 3400, 0.72, 1) : 1;
    // Device protection if an observed cooling fault is diagnosed, not a repair action.
    const mitigation = f.diagnostics && state.fault === 'cooling' && time > state.faultTime ? 0.80 : 1;
    clock *= mitigation;
    const capacity = CONFIG.gpuCount * CONFIG.gpuCapacitySecondsPerMinute * CONFIG.schedulerEfficiency * clock;
    const demandLow = heatDemand < 39 && state.storageKWh > Math.max(6, c.storageCap * 0.55);
    // Deadline-first ordering can change with switch; flexible work may be deferred for at most 2 steps.
    if (f.thermal) state.queue.sort((a,b) => a.deadline - b.deadline || Number(a.flexible) - Number(b.flexible) || a.id-b.id);
    let used = 0, tokensOut = 0, smallDone=0, largeDone=0, completed=0, ontime=0, goodDone=0;
    const waiting=[];
    for (const job of state.queue) {
      const shouldDefer = f.thermal && demandLow && job.flexible && time - job.created < 2 && job.deadline - time > 2;
      if (shouldDefer || used >= capacity - 1e-6) { waiting.push(job); continue; }
      const allow = Math.min(capacity-used, job.remaining);
      job.remaining -= allow; used += allow;
      if (job.remaining > 1e-7) { waiting.push(job); continue; }
      completed++;
      tokensOut += job.outputTokens;
      if(job.small) smallDone++; else largeDone++;
      if (time+1 <= job.deadline) ontime++;
      if (job.good) goodDone++;
    }
    state.queue = waiting;
    const util = clamp(used / Math.max(1,capacity), 0, 1);
    // IT power uses idle + scaled dynamic power (illustrative DVFS law).
    const gpuPower = CONFIG.gpuCount * (CONFIG.gpuIdleKW + CONFIG.gpuDynamicKW * util * Math.pow(clock,2.15));
    const itKW = CONFIG.nonGpuITKW + gpuPower;
    // Fault affects cooling telemetry and chip junction model; heat balance simplified.
    const coolantFlow = state.fault === 'cooling' ? 2.05 : CONFIG.normalCoolantFlowKgS;
    const predicted = 41 + 28 * util + clamp((c.outside-14)*0.18,0,4) + 0.65 * (1-clock);
    const physicalExtra = state.fault === 'cooling' ? 13 : 0;
    const thermalTarget = predicted + physicalExtra;
    state.temp += (thermalTarget - state.temp) * 0.49;
    const observed = state.temp;
    const residual = observed - predicted;
    const cells = Array.from({length:64}, (_,i) => {
      // Fixed device-to-device variance for rack placement, plus modeled hotspot.
      const rack = Math.floor(i/8), lane = i%8;
      const variance = 1.7*Math.sin((i+1)*2.39) + 0.90*(rack-3.5)/3.5 + (lane===0?1.15:0);
      const hotspot = state.fault==='cooling' && (rack===5 || rack===6) ? 4.1 : 0;
      return clamp(observed + variance + hotspot, 20, 105);
    });
    const peak = Math.max(...cells);
    const faultDetected = !!f.diagnostics && state.fault === 'cooling' && residual > 4.5;
    const diagnosis = !f.diagnostics ? 'monitoring-off' : faultDetected ? 'flow-restriction' : residual > 4.5 ? 'unknown-anomaly' : 'normal';
    // Thermodynamic simplified allocation: heat pump uses low-grade recovered heat as evaporator source.
    const captureKW = itKW * CONFIG.captureFraction * CONFIG.heatExchangerEffectiveness;
    const cop = CONFIG.heatPumpCOP;
    const heatPumpPotential = captureKW * cop / (cop - 1);
    const availableStorage = Math.max(0,c.storageCap-state.storageKWh);
    const surplusPotential = Math.max(0,heatPumpPotential-heatDemand);
    const charge = Math.min(surplusPotential, availableStorage * 60, 35); // kW
    const heatPumpProduction = Math.min(heatPumpPotential, heatDemand+charge);
    const toLoads = Math.min(heatDemand, heatPumpProduction);
    const discharge = Math.min(Math.max(0,heatDemand-toLoads), state.storageKWh*60*0.95, 40);
    state.storageKWh = clamp(state.storageKWh + charge * 0.92 / 60 - discharge / (0.95*60),0,c.storageCap);
    const usefulHeat = toLoads + discharge;
    const backupElectricHeat = Math.max(0,heatDemand-usefulHeat); // electric resistance backup, COP = 1
    const heatPumpElectric = heatPumpProduction / cop;
    const heatTakenFromIT = heatPumpProduction - heatPumpElectric;
    const heatRejected = Math.max(0,itKW - heatTakenFromIT);
    const coolingAndPumpKW = 2.0 + itKW*0.035 + heatRejected*0.045 + (state.fault==='cooling'?0.9:0);
    const ancillaryKW = 2.0;
    const facilityKW = itKW + coolingAndPumpKW + heatPumpElectric + ancillaryKW;
    const siteKW = facilityKW + backupElectricHeat;
    const gridKW = siteKW*(1-c.renewables);
    const secondaryBranchDelivered = Object.fromEntries(Object.entries(demand).map(([key,value])=>[key,value*usefulHeat/Math.max(0.001,heatDemand)]));
    state.total.energyKWh+=siteKW/60;
    state.total.heatKWh+=usefulHeat/60;
    state.total.tokens+=tokensOut;
    state.total.completions+=completed;
    state.total.deadlines+=ontime;
    state.total.quality+=goodDone;
    const data = {t:time+1, arrivals, queue:state.queue.length, util, clock, itKW, facilityKW, siteKW, gridKW,
      tokensPerS:tokensOut/60, outputTokens:tokensOut, smallDone,largeDone, completed, ontime,goodDone,
      avgTemp:observed, expectedTemp:predicted, residual, peakTemp:peak, cells, coolantFlow,
      heatDemand, heat:usefulHeat, heatPumpProduction, heatPumpElectric, captured:captureKW,
      rejected:heatRejected, storage:state.storageKWh, backup:backupElectricHeat,
      branchDelivered:secondaryBranchDelivered, diagnosis, missed:completed-ontime,
      health:diagnosis==='normal'?'NORMAL':diagnosis==='monitoring-off'?'UNMONITORED':'ALERT',
      qualityPct:completed?100*goodDone/completed:100, slaPct:state.total.completions?100*state.total.deadlines/state.total.completions:100,
      renewablePct:c.renewables*100 };
    state.current=data;
    state.history.push(data);
    if(state.history.length>CONFIG.historyLength) state.history.shift();
    state.t++;
    return data;
  }
  function evaluate(controls) {
    const st = createState(controls);
    for (let i=0;i<60;i++) step(st);
    const r=st.total;
    const tokensMillions=r.tokens/1e6;
    return {kWhPerMillion: r.energyKWh/Math.max(0.00001,tokensMillions),
      heatKWh: r.heatKWh, sla: r.completions?100*r.deadlines/r.completions:0,
      quality: r.completions?100*r.quality/r.completions:0,
      energy:r.energyKWh, complete:r.completions};
  }
  function chart(canvas, entries, series, minValue, maxValue, unit, fixedTicks) {
    const bounds=canvas.getBoundingClientRect();
    if(bounds.width<=0)return;
    const dpr=Math.max(1,Math.min(2,window.devicePixelRatio||1));
    const W=bounds.width,H=bounds.height;
    canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);
    const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,W,H);
    const m={top:13,right:12,bottom:27,left:36};
    const x0=m.left,x1=W-m.right,y0=m.top,y1=H-m.bottom;
    let lows=entries.flatMap(e=>series.map(s=>e[s.key]));
    const min=minValue===null?Math.max(0,Math.min(...lows,0)*.9):minValue;
    const max=maxValue===null?Math.max(10,Math.max(...lows,10)*1.17):maxValue;
    ctx.strokeStyle='#254059';ctx.lineWidth=1;ctx.font='10px Inter, sans-serif';ctx.fillStyle='#6d8a9e';
    for(let i=0;i<5;i++){
      const y=y0+(y1-y0)*i/4;
      ctx.beginPath();ctx.moveTo(x0,y);ctx.lineTo(x1,y);ctx.stroke();
      const v=max-(max-min)*i/4;
      ctx.fillText((fixedTicks?Math.round(v):Math.round(v))+unit,0,y+3);
    }
    const N=entries.length;
    if(N===0)return;
    const X=i=>x0+((x1-x0)*(N===1?0.5:i/(N-1)));
    const Y=v=>clamp(y1-(v-min)/(max-min)*(y1-y0),y0,y1);
    for(const s of series){
      ctx.beginPath();ctx.lineWidth=2.1;ctx.strokeStyle=s.color;ctx.lineJoin='round';
      entries.forEach((entry,i)=>{const y=Y(entry[s.key]);i?ctx.lineTo(X(i),y):ctx.moveTo(X(i),y)});
      ctx.stroke();
      const end=entries[N-1];ctx.fillStyle=s.color;
      ctx.beginPath();ctx.arc(X(N-1),Y(end[s.key]),3,0,Math.PI*2);ctx.fill();
    }
    ctx.fillStyle='#607f98';ctx.fillText('T-'+Math.max(0,N-1)+'m',x0,y1+17);ctx.fillText('Now',Math.max(x0,x1-25),y1+17);
  }
  function setText(id, value){const el=$(id);if(el)el.textContent=value;}
  function setWidth(id, percent){const el=$(id);if(el)el.style.width=clamp(percent,0,100)+'%';}
  function colorForTemp(t) {
    // Gradient from cool blue to teal -> amber -> orange -> pink.
    const stops=[[38,[23,100,149]],[51,[40,162,180]],[65,[220,166,85]],[78,[241,113,79]],[95,[194,48,88]]];
    if(t<=38)return '#176495';
    for(let i=1;i<stops.length;i++)if(t<=stops[i][0]){
      const a=stops[i-1], b=stops[i],p=(t-a[0])/(b[0]-a[0]);
      return 'rgb('+a[1].map((v,j)=>Math.round(v+(b[1][j]-v)*p)).join(',')+')';
    }
    return '#c23058';
  }
  let engine, running=true, timer, benchmarkTimeout, faultLastStatus='normal';
  const gridCells=[];
  function timeStr(time){return 'T+ '+String(Math.floor(time/60)).padStart(2,'0')+':'+String(time%60).padStart(2,'0');}
  function addLog(message,severity='info', t=engine?.t||0){
    const div=document.createElement('div');div.className='event severity-'+severity;
    const tm=document.createElement('span');tm.className='event-time';tm.textContent=timeStr(t);
    const msg=document.createElement('span');msg.className='event-text';msg.textContent=message;
    div.append(tm,msg);$('eventLog').prepend(div);
    while($('eventLog').children.length>24)$('eventLog').lastElementChild.remove();
  }
  function draw() {
    const s=engine, v=s.current;if(!v)return;
    setText('simClock',timeStr(s.t));
    setText('sitePower',fmt(v.siteKW));setText('itPower',fmt(v.itKW));
    setText('tokens',Math.round(v.tokensPerS).toLocaleString());
    setText('heat',fmt(v.heat));setText('temperature',fmt(v.avgTemp));setText('healthStatus',v.health);
    setText('sitePowerSub','Grid draw '+fmt(v.gridKW)+' kW');
    setText('itPowerSub',fmt(100*v.util,0)+'% GPU utilization');
    setText('tokensSub',v.completed+' jobs completed this minute');
    setText('heatSub','Demand '+fmt(v.heatDemand)+' kW · backup '+fmt(v.backup)+' kW');
    setText('temperatureSub','Expected '+fmt(v.expectedTemp)+'°C · peak '+fmt(v.peakTemp)+'°C');
    setText('healthSub',v.diagnosis==='monitoring-off'?'Fault monitor disabled':v.diagnosis==='normal'?'No detected anomaly':'Possible cooling anomaly');
    $('healthStatus').style.color=v.health==='ALERT'?'#fb8b93':v.health==='UNMONITORED'?'#fbbf7b':'#77e3bf';
    setWidth('siteBar',v.siteKW/155*100);setWidth('itBar',v.itKW/85*100);
    setWidth('tokenBar',v.tokensPerS/1600*100);setWidth('heatBar',v.heat/85*100);
    setWidth('tempBar',v.avgTemp/95*100);setWidth('healthBar',v.health==='ALERT'?87:v.health==='UNMONITORED'?24:100);
    if(window.ThermaLoop3D)window.ThermaLoop3D.update(v,s.controls);
    setText('svgGpu',fmt(v.itKW)+' kW IT');setText('svgCapture',fmt(v.captured)+' kW capturable');
    setText('svgDelivered',fmt(v.heat)+' kW delivered');
    setText('svgBuilding',fmt(v.branchDelivered.building)+' kW');
    setText('svgLab',fmt(v.branchDelivered.laboratory)+' kW · selected zones');
    setText('svgSeed',fmt(v.branchDelivered.seed)+' kW · germination');
    setText('svgGreenhouse',fmt(v.branchDelivered.greenhouse)+' kW');
    setText('svgStorage','Stored '+fmt(v.storage)+' kWh');
    setText('svgRejected',fmt(v.rejected)+' kW rejected');
    setText('loopText','Heat demand '+fmt(v.heatDemand)+' kW');
    setText('utilValue',fmt(v.util*100,0)+'%');setText('clockValue',fmt(v.clock,2)+'×');
    setText('queueValue',String(v.queue));setText('deadlineValue',fmt(v.slaPct,1)+'%');
    setWidth('utilFill',v.util*100);setWidth('clockFill',v.clock*100);
    setWidth('queueFill',v.queue/600*100);setWidth('deadlineFill',v.slaPct);
    const mix=v.smallDone+v.largeDone;
    const smallPct=mix?100*v.smallDone/mix:0;
    setWidth('smallModelBar',smallPct);setWidth('largeModelBar',100-smallPct);
    setText('modelMixText',fmt(smallPct,0)+'% small / '+fmt(100-smallPct,0)+'% large');
    let insight='The dispatcher uses available GPU capacity and honors per-job deadlines.';
    if(s.controls.active.thermal)insight=v.heatDemand<40?'Low heat demand: flexible jobs may be deferred briefly within deadline slack.':'Heat demand is elevated: run queued jobs subject to compute efficiency and deadline constraints.';
    if(v.queue>240)insight='Queue pressure is high. Increase resources or reduce arrival rates to protect latency.';
    if(v.diagnosis==='flow-restriction')insight='Cooling anomaly detected. The model reduces GPU clock speed and flags the liquid cooling circuit for inspection.';
    setText('schedulerInsight',insight);
    for(let i=0;i<64;i++){gridCells[i].style.background=colorForTemp(v.cells[i]);gridCells[i].textContent=String(Math.round(v.cells[i]));gridCells[i].title='GPU '+String(i+1).padStart(2,'0')+': '+fmt(v.cells[i])+'°C';}
    setText('peakGpu',fmt(v.peakTemp)+'°C');setText('residualValue',(v.residual>0?'+':'')+fmt(v.residual)+'°C');
    setText('flowValue',fmt(v.coolantFlow,2)+' kg/s');
    const cause = v.diagnosis==='monitoring-off'?'Monitoring disabled':v.diagnosis==='flow-restriction'?'Low-flow cooling restriction (hypothesis)':v.diagnosis==='unknown-anomaly'?'Unclassified thermal anomaly':'No detected anomaly';
    const action=v.diagnosis==='monitoring-off'?'Enable diagnostics to evaluate telemetry':v.diagnosis==='flow-restriction'?'Investigate pump / flow sensors; automated derating modeled':v.diagnosis==='unknown-anomaly'?'Check sensors, clocks and cooling':'Continue monitoring';
    setText('causeValue',cause);setText('actionValue',action);
    const pill=$('diagnosisPill');pill.textContent=v.diagnosis==='normal'?'NORMAL':v.diagnosis==='monitoring-off'?'OFF':'ANOMALY';pill.className=v.diagnosis==='normal'?'pill-good':'pill-warn';
    const history=s.history;
    chart($('powerChart'),history,[{key:'siteKW',color:'#61c7ee'},{key:'heat',color:'#ffb470'},{key:'heatDemand',color:'#97adbf'}],0,null,'',true);
    chart($('tempChart'),history,[{key:'avgTemp',color:'#61c7ee'},{key:'expectedTemp',color:'#a78bfa'},{key:'peakTemp',color:'#fb7185'}],30,100,'°',true);
    if(v.diagnosis==='flow-restriction'&&faultLastStatus!=='flow-restriction')addLog('Thermal model residual crossed threshold; coolant mass flow also fell. Hypothesis: restricted cooling flow.','warning');
    if(v.diagnosis==='normal'&&faultLastStatus==='flow-restriction')addLog('Temperatures and coolant telemetry returned toward nominal operating range.','success');
    faultLastStatus=v.diagnosis;
    if(v.t%15===0)addLog('Minute '+v.t+': '+v.completed+' jobs completed, '+fmt(v.heat)+' kW useful heat delivered.');
  }
  function tick(){step(engine);draw();}
  function pause(){running=false;clearInterval(timer);$('playLabel').textContent='Run';$('playIcon').textContent='▶';$('liveText').textContent='SIMULATION PAUSED';document.querySelector('.live-indicator').classList.add('paused');}
  function play(){if(running)return;running=true;timer=setInterval(tick,900);$('playLabel').textContent='Pause';$('playIcon').textContent='Ⅱ';$('liveText').textContent='LIVE SIMULATION';document.querySelector('.live-indicator').classList.remove('paused');}
  function reset(){const c=readControls();engine=createState(c);faultLastStatus='normal';if(window.ThermaLoop3D)window.ThermaLoop3D.reset();$('eventLog').replaceChildren();addLog('Initialized 64-GPU data center + parallel heat recovery, research labs, seed germination and greenhouse branches.','success',0);tick();}
  function queueBenchmark(){clearTimeout(benchmarkTimeout);benchmarkTimeout=setTimeout(runBenchmark,180);}
  function runBenchmark(){
    const c=readControls();
    const baseline=evaluate({...c,active:allOff()});
    const current=evaluate(c);
    setText('benchEnergyBase',fmt(baseline.kWhPerMillion,1)+' kWh');setText('benchEnergyOpt',fmt(current.kWhPerMillion,1)+' kWh');
    setText('benchHeatBase',fmt(baseline.heatKWh,1)+' kWh');setText('benchHeatOpt',fmt(current.heatKWh,1)+' kWh');
    setText('benchSlaBase',fmt(baseline.sla,1)+'%');setText('benchSlaOpt',fmt(current.sla,1)+'%');
    setText('benchQualityBase',fmt(baseline.quality,1)+'%');setText('benchQualityOpt',fmt(current.quality,1)+'%');
    const delta=(current.kWhPerMillion/baseline.kWhPerMillion-1)*100;
    const movement=delta<-0.1?fmt(Math.abs(delta),1)+'% less':delta>0.1?fmt(delta,1)+'% more':'roughly unchanged';
    setText('benchmarkInsight','Current configuration uses '+movement+' simulated electricity per 1M generated tokens versus the unoptimized baseline. Compare deadline success and synthetic quality before interpreting energy differences.');
  }
  function applyScenario(name) {
    const values={standard:[190,5,25,100],winter:[185,-13,35,180],burst:[300,1,15,100],summer:[185,30,50,175],fault:[190,5,25,100]};
    const v=values[name]||values.standard;
    $('demandRange').value=v[0];$('tempRange').value=v[1];$('solarRange').value=v[2];$('storageRange').value=v[3];
    refreshControlLabels();reset();
    if(name==='fault')injectFault();
    addLog('Scenario loaded: '+$('scenario').selectedOptions[0].text+'.');
    queueBenchmark();
  }
  function injectFault(){engine.fault='cooling';engine.faultTime=engine.t;addLog('FAULT INJECTION: coolant flow restricted (4.0 → 2.05 kg/s). Synthetic test only.','warning');}
  function clearFault(){engine.fault=null;engine.faultTime=-1;addLog('Cooling fault injection cleared; simulated flow restored.','success');}
  function refreshControlLabels(){setText('demandValue',$('demandRange').value);setText('tempValue',$('tempRange').value+'°C');setText('solarValue',$('solarRange').value+'%');setText('storageValue',$('storageRange').value+' kWh');}
  function exportCSV(){
    const headers=['minute','arrival_requests','completed_requests','queue_requests','generated_tokens_per_second','site_electric_kw','it_kw','useful_heat_kw','thermal_demand_kw','rejected_heat_kw','stored_heat_kwh','grid_kw','backup_electric_heat_kw','gpu_utilization','gpu_clock_multiplier','gpu_temperature_observed_c','gpu_temperature_predicted_c','gpu_peak_c','temperature_residual_c','coolant_flow_kg_s','diagnosis'];
    const keys=['t','arrivals','completed','queue','tokensPerS','siteKW','itKW','heat','heatDemand','rejected','storage','gridKW','backup','util','clock','avgTemp','expectedTemp','peakTemp','residual','coolantFlow','diagnosis'];
    const rows=[headers.join(','),...engine.history.map(e=>keys.map(k=>String(e[k])).join(','))];
    const blob=new Blob([rows.join('\n')],{type:'text/csv;charset=utf-8'});
    const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;
    a.download='thermaloop_ai_simulation_'+engine.t+'min.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
    addLog('Exported '+engine.history.length+' simulated minutes as a CSV file.','success');
  }
  function init(){
    for(let i=0;i<64;i++){const span=document.createElement('div');span.className='gpu-cell';span.setAttribute('role','img');span.setAttribute('aria-label','GPU '+(i+1)+' temperature');$('gpuGrid').appendChild(span);gridCells.push(span);}
    ['demandRange','tempRange','solarRange','storageRange'].forEach(id=>$(id).addEventListener('input',()=>{
      refreshControlLabels();engine.controls=readControls();engine.storageKWh=Math.min(engine.storageKWh,engine.controls.storageCap);queueBenchmark();
    }));
    toggles.forEach(key=>$(key+'Toggle').addEventListener('change',()=>{engine.controls=readControls();addLog('Strategy updated: '+key+' '+(engine.controls.active[key]?'enabled':'disabled')+'.');queueBenchmark();}));
    $('allOnBtn').addEventListener('click',()=>{toggles.forEach(key=>$(key+'Toggle').checked=true);engine.controls=readControls();addLog('All five optimization strategies enabled.','success');queueBenchmark();});
    $('scenario').addEventListener('change',e=>applyScenario(e.target.value));
    $('playBtn').addEventListener('click',()=>running?pause():play());
    $('stepBtn').addEventListener('click',()=>{pause();tick();});
    $('resetBtn').addEventListener('click',()=>{reset();queueBenchmark();});
    $('injectFaultBtn').addEventListener('click',injectFault);
    $('clearFaultBtn').addEventListener('click',clearFault);
    $('benchmarkBtn').addEventListener('click',runBenchmark);
    $('toggle2d').addEventListener('click',e=>{const s2=$('schematic2d'),w3=$('scene3d');const to2d=s2.hidden;s2.hidden=!to2d;[...w3.querySelectorAll('canvas,.scene3d-hint')].forEach(n=>n.style.display=to2d?'none':'');w3.style.height=to2d?'44px':'';e.target.textContent=to2d?'3D view':'2D schematic';});
    $('clearLogBtn').addEventListener('click',()=>$('eventLog').replaceChildren());
    $('exportBtn').addEventListener('click',exportCSV);
    window.addEventListener('resize',()=>{if(engine.current)draw();});
    document.querySelectorAll('.side-nav a').forEach(a=>a.addEventListener('click',()=>{
      document.querySelectorAll('.side-nav a').forEach(x=>x.classList.remove('active'));a.classList.add('active');
    }));
    refreshControlLabels();reset();runBenchmark();timer=setInterval(tick,900);
  }
  window.ThermaLoopSimulator={CONFIG,createState,step,evaluate,allOn,allOff,thermalDemand};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
