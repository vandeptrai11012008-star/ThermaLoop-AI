# ThermaLoop AI — Scale, Financial Impact & Project Conditions

**Research demonstration; not a calibrated digital twin and not a financial quote.**

## Run it

- Open `index.html` or the delivered `ThermaLoop_AI_Scale_Economics_Conditions.html` in Chrome/Edge. This is a **standalone, dependency-free** HTML website.
- The updated site preserves the existing interactive 3D campus, 64 individually modeled synthetic GPUs, workload allocation, per-GPU Before/After analytics, the primary GPU cooling loop and the campus heat-recovery visualization.
- Go to **Scale & economics** in the left navigation, beneath the GPU allocation lab.
- Adjust target daily request volume, peak multiplier, a reserved GPU headroom percentage, N+1 spare, utility tariff, solar share, heat demand, per-GPU capex and ongoing software cost.
- In **Six project conditions**, set network RTT, P95 interactive latency target, long-context VRAM assumptions, batch flexibility/deadline window, and inject a one-pod failure.
- The **Hourly price & solar** tab plots when work is served under the same fixed demand, and how solar changes grid prices. The **Equations & limitations** tab exposes the model structure and assumptions.
- Use **Export scale study (JSON)** to record assumptions, hourly curves and results. The data is synthetic and should not be used to justify real capex without validation.

## Six binding conditions (the user's project requirements)

1. **Interactive latency:** demand burst sizing and a queueing/RTT proxy must satisfy a user-supplied P95 latency threshold. Do not confuse this proxy with actual TTFT or an observed tail-latency benchmark.
2. **Fixed daily task volume:** both variants receive the *same total daily job volume*. The economics always includes a 24/7 idle-power floor for all installed GPUs/pods. There is no fictitious cost reduction from silently dropping tasks or switching off servers.
3. **Long-context jobs:** model weights + concurrent KV-cache footprint must fit into each device's selected VRAM envelope. If an individual worker runs out of VRAM, installing more unsharded GPUs is not treated as a solution. Context length also reduces synthetic serving throughput.
4. **Flexible batch deadlines:** only a user-selected share of batch tasks can shift toward cheaper hours, and only up to the specified delay. Any scheduling failure produces a warning; fixed total tasks are preserved.
5. **Demand bursts:** the model sizes based on the larger of the configured peak multiplier and the average, including a safety loading ceiling and reservable headroom.
6. **Failure reserve:** explicit N+1 spare 64-GPU pod, paid-for even when idle. A fault test removes one pod and checks contingency capacity.

## Math and financial accounting

The primary 60-minute paired 64-GPU simulated experiment is the source of per-pod site power and tasks completed/hour. This experimental envelope is re-used as a **synthetic per-pod profile** for large deployments; there are no empirical scale-up benchmarks.

- Assumed model throughput per pod under long-context mix: `completed_requests_per_hour / [1 + long_share * max(0, context_tokens/8192 - 1) * 0.45]`.
- Device VRAM estimate: `model_weight_GiB + (context_tokens / 1000) * KV_GiB_per_1k_tokens * concurrent_long_sessions`.
- Demand cap: `target_daily_requests / 24 * peak_multiplier`.
- Operating pod count: smallest integer whose reserved capacity can satisfy demand at a maximum synthetic utilization of 83% **and** a queue/RTT latency proxy below the specified threshold; one N+1 pod added if selected.
- Installed same-fleet size is the **greater** of baseline and optimized required pods; both consume idle power all day. This deliberately prevents a false apples-to-oranges cost reduction from turning servers off.
- Per-pod synthetic minimum on-state floor: `max(19 + 64*0.14 + 4.5, min(before.siteKW, after.siteKW)*0.36) kW`.
- Daily site energy: `24 * common_installed_pods * idle_pod_kW + target_jobs * (measured_pod_kW - idle_pod_kW) / long_context_adjusted_jobs_per_hour`.
- Hourly effective retail rate: peak or offpeak tariff times `(1 - assumed_daylight_solar_share_at_hour)`.
- The baseline and optimized cases have identical daily task volume, with the optimized case additionally allowed to move flexible tasks into lower-price hours. Electricity bill difference is split into compute-envelope difference + scheduling difference. This is **not** a double count.
- Annual savings: simulated daily electricity bill difference times configured operating days/year.
- Net annual change: annual grid bill difference minus incremental software OPEX (does **not** mean corporate net profit).
- Right-sizing capex: difference in recommended required pod counts times 64 times editable GPU/support cost. Separate from electricity savings; not summed into annual net.
- Heat reuse value is limited by a **user-provided thermal buyer load** and a heat-price assumption. **Both existing 64-GPU Before and After scenarios already reuse heat**, so this is displayed separately as an opportunity, **not added** to incremental annual savings.
- The optional campus heat-loop capital cost is separately listed in total project capital. A simple software investment payback uses *only incremental software setup cost* vs *net incremental software savings*; it is not a complete project IRR.

## Example baseline (synthetic, not independently verified)

Initial values: `300,000 requests/day`, `1.8×` burst multiplier, `15%` spare throughput headroom, `N+1` reserve, `80 GiB GPU VRAM`, `32,768-token long context` at `30%` share, `0.13/0.28 $/kWh` tariff, `25%` daytime solar grid offset, `30%` flexible tasks, `$32,000` per GPU + support. The website's sample run returns **6 pods / 384 GPUs** for both policies, a synthetic electricity-bill difference of about **$74,781/year** and a synthetic net of **$44,781/year** after `$30,000/year` incremental software OPEX. The result will change if you toggle GPU strategies or adjust assumptions. It is not a defensible savings guarantee.

## The difference between this demo and genuine engineering validation

The website's 64-GPU simulator does not measure GPU clocks or power on hardware, nor does it simulate actual prefill/decode queues, KV-cache residency, memory fragmentation, demand charges, detailed hydraulic network flow or building cooling load. The separate scale calculator uses a **latency proxy**, a simplified VRAM/throughput model, an assumed hourly solar/weather shape and no uncertainty intervals. Conditions passing here do **not** establish real-world design feasibility.

Recommended validation before an academic submission or investment case: measured per-GPU DCGM/NVML power/clocks/temperatures, serving throughput & tail latency under controlled long-context concurrency, multi-day request traces, realistic batch deadlines, local tariff/solar supply data, measured heat exchanger/heat pump COP and secondary hydronic flow/supply-return temperatures, engineering sizing of redundancy, and an error/bounds analysis.

## Files

- `index.html` — all-in-one runnable website
- `scale_lab.css` — separate readable copy of the newly added interface styles
- `scale_lab.js` — separate readable copy of the newly added economic/condition analysis (already embedded in index.html)
- `README.md` — this technical explanation
