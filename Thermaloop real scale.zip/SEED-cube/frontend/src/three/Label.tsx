import { Html } from "@react-three/drei";

export default function EngineeringLabel({
  text,
  className = "",
  subtext,
  position = [0, 0, 0],
  accent = "#62b6ff",
}: {
  text: string;
  className?: string;
  subtext?: string;
  position?: [number, number, number];
  accent?: string;
}) {
  return (
    <Html position={position} center zIndexRange={[4, 0]}>
      <div className={`engineering-label ${className}`} style={{ borderColor: accent }}>
        <strong>{text}</strong>
        {subtext && <span>{subtext}</span>}
      </div>
    </Html>
  );
}
